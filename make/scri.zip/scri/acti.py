
def Acti(actiValu, upda):
	if upda:
		if actiValu == 0:
			actiValu = 1
	else:
		actiValu = 3
	return actiValu

